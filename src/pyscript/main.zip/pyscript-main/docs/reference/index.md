# Reference

This reference section will have manually documented or fully
automated code documentation. **Coming soon!**

```{toctree}
---
maxdepth: 1
glob:
---
faq
